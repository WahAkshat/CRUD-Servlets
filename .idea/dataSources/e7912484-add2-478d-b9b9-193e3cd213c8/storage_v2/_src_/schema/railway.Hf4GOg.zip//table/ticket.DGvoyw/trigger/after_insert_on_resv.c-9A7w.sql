create definer = root@localhost trigger after_insert_on_resv
    after insert
    on ticket
    for each row
begin
UPDATE classseats SET seatsleft=seatsleft-new.nos where trainno=new.trainno AND class=new.class AND sp=new.sp AND dp=new.dp;
end;

