create PROCEDURE ticket_of_Passenger(
pass_name VARCHAR
)
IS
r_pass_name Passenger JOIN Ticket %ROWTYPE;
BEGIN
-- get passenger name on pnr_no
SELECT *
INTO r_pass_name
FROM Passenger JOIN Ticket
ON ticket.PNRNO = Passenger.PNRNO
WHERE ticket.from_station=’Bangalore’AND
Ticket.to_station=’Katpadi’
-- print out contact's information
dbms_output.put_line(r_pass_name);
EXCEPTION
WHEN OTHERS THEN
dbms_output.put_line( SQLERRM );
END;
/

