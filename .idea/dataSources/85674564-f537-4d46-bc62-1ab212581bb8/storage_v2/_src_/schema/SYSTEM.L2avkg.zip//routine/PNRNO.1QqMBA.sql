create PROCEDURE pnrno(
PNR_No1 NUMBER(11)
)
IS
r_PNR_NO1 Train JOIN Ticket %ROWTYPE;
DECLARE
Source VARCHAR
Destination VARCHAR
BEGIN
-- get contact based on customer id
SELECT PNR_NO
INTO r_PNR_NO1
FROM Train JOIN Ticket
ON ticket.train_no = Passenger.train_no
WHERE Source=&Source
Destination=&Destination
REPORT TITLE
23
-- print out pnrno’s information
dbms_output.put_line(r_PNR_NO1);
EXCEPTION
WHEN OTHERS THEN
dbms_output.put_line( SQLERRM );
END;
/

