create procedure passpnr(a varchar,b varchar)
is
pnr ticket.PNR_No%type;
begin
select PNR_No into pnr from ticket natural join Train where source=a and
destination=b;
dbms_output.put_line(pnr);
end;
/

