create procedure facto(n number) is
fact number:=1;
qwerty number;
begin
qwerty:=n;
while(qwerty>0)
loop
fact:=fact*qwerty;
qwerty:=qwerty-1;
end loop;
dbms_output.put_line('The Factorial of the number is : '||fact);
end facto;
/

