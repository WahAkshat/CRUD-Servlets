create function total(pnr number)
return number
is
t number;
begin
select count(*) into t from passenger group by pnr_num having
pnr_num=pnr;
return t;
end;
/

