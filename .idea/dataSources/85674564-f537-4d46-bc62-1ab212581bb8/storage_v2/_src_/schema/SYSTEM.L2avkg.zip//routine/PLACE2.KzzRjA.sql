create function place2(trainnumber number)
return varchar
is
ddestination varchar(10);
begin
select destination into ddestination from train where train_Number=trainnumber;
return ddestination;
end;
/

