create procedure passname
is
pname passenger.passenger_name%type;
begin
select passenger_name into pname from Passenger,Ticket where passenger.pnr_num = ticket.PNRNo and 
from_station='Katpadi' and to_station='Bangalore';
dbms_output.put_line(pname);
end;
/

