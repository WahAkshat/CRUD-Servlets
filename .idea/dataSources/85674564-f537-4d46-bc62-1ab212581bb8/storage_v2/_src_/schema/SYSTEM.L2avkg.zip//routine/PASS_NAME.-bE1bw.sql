create procedure pass_name
is
pname Passenger.passenger_name%type;
begin
select passenger_name into pname from Passenger natural join Ticket where
from_station='Katpadi' and to_station='Bangalore';
dbms_output.put_line(pname);
end;
/

