create procedure pass_pnr(a varchar,b varchar)
is
pnr Ticket.PNRNo%type;
begin
select PNRNo into pnr from Ticket natural join Train where from_station=a and
to_station=b;
dbms_output.put_line(pnr);
end;
/

