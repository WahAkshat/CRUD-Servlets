create function place(trainnumber number)
return varchar
is
ssource varchar(10);
begin
select source into ssource from train where train_Number=trainnumber;
return ssource;
end;
/

